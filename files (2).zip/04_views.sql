-- ============================================================
--  Healthcare Diagnosis & Financial Analysis
--  File: 04_views.sql
--  Author: Akash Mishra
--  Description: Reusable views for Power BI and reporting
-- ============================================================


-- ────────────────────────────────────────────────────────────
--  VIEW 1: Diagnosis Cost Summary
--  Use: Power BI Page 2 & 3 — condition-level KPIs
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW vw_diagnosis_cost_summary AS
SELECT
    medical_condition,
    COUNT(*)                                                    AS total_patients,
    ROUND(AVG(billing_amount),       2)                         AS avg_billing,
    ROUND(AVG(length_of_stay),       2)                         AS avg_los_days,
    ROUND(AVG(cost_per_day),         2)                         AS avg_cost_per_day,
    ROUND(SUM(billing_amount) / 1000000.0, 3)                   AS total_revenue_millions,
    SUM(CASE WHEN test_results = 'Abnormal'     THEN 1 ELSE 0 END) AS abnormal_count,
    SUM(CASE WHEN test_results = 'Normal'       THEN 1 ELSE 0 END) AS normal_count,
    SUM(CASE WHEN test_results = 'Inconclusive' THEN 1 ELSE 0 END) AS inconclusive_count,
    ROUND(SUM(CASE WHEN test_results = 'Abnormal' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS abnormal_rate_pct,
    ROUND(SUM(CASE WHEN admission_type = 'Emergency' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS emergency_rate_pct
FROM healthcare
WHERE billing_flag = 'normal'
GROUP BY medical_condition;

-- Preview
-- SELECT * FROM vw_diagnosis_cost_summary ORDER BY avg_billing DESC;


-- ────────────────────────────────────────────────────────────
--  VIEW 2: High Billing Patients
--  Use: Power BI table visual — high-cost patient list
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW vw_high_billing_patients AS
SELECT
    patient_name,
    age,
    age_group,
    gender,
    blood_type,
    medical_condition,
    insurance_provider,
    admission_type,
    admission_date,
    discharge_date,
    length_of_stay,
    ROUND(billing_amount, 2)  AS billing_amount,
    ROUND(cost_per_day,   2)  AS cost_per_day,
    medication,
    test_results,
    high_billing_flag
FROM healthcare
WHERE billing_flag      = 'normal'
  AND high_billing_flag = 'high_cost'
ORDER BY billing_amount DESC;

-- Preview
-- SELECT * FROM vw_high_billing_patients LIMIT 20;


-- ────────────────────────────────────────────────────────────
--  VIEW 3: Insurance Provider Performance
--  Use: Power BI Page 3 — financial breakdown by insurer
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW vw_insurer_performance AS
SELECT
    insurance_provider,
    COUNT(*)                                               AS total_patients,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 2)     AS volume_share_pct,
    ROUND(SUM(billing_amount) / 1000000.0, 3)              AS total_revenue_millions,
    ROUND(SUM(billing_amount) * 100.0
          / SUM(SUM(billing_amount)) OVER(), 2)            AS revenue_share_pct,
    ROUND(AVG(billing_amount), 2)                          AS avg_claim,
    ROUND(MIN(billing_amount), 2)                          AS min_claim,
    ROUND(MAX(billing_amount), 2)                          AS max_claim,
    ROUND(AVG(length_of_stay), 2)                          AS avg_los_days,
    SUM(CASE WHEN test_results = 'Abnormal' THEN 1 ELSE 0 END)  AS abnormal_cases,
    ROUND(SUM(CASE WHEN test_results = 'Abnormal' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS abnormal_pct
FROM healthcare
WHERE billing_flag = 'normal'
GROUP BY insurance_provider;

-- Preview
-- SELECT * FROM vw_insurer_performance ORDER BY total_revenue_millions DESC;


-- ────────────────────────────────────────────────────────────
--  VIEW 4: Monthly Admission Trends
--  Use: Power BI Page 2 — time-series line charts
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW vw_monthly_admission_trends AS
SELECT
    admission_year,
    admission_month,
    admission_month_name,
    admission_quarter,
    medical_condition,
    COUNT(*)                           AS admissions,
    ROUND(AVG(billing_amount), 2)      AS avg_billing,
    ROUND(SUM(billing_amount), 2)      AS total_billing,
    ROUND(AVG(length_of_stay), 2)      AS avg_los
FROM healthcare
WHERE billing_flag = 'normal'
GROUP BY admission_year, admission_month, admission_month_name,
         admission_quarter, medical_condition
ORDER BY admission_year, admission_month, medical_condition;

-- Preview
-- SELECT * FROM vw_monthly_admission_trends WHERE admission_year = 2023;


-- ────────────────────────────────────────────────────────────
--  VIEW 5: Executive Summary KPIs
--  Use: Power BI Page 1 — KPI cards
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW vw_executive_kpis AS
SELECT
    COUNT(*)                                                     AS total_patients,
    ROUND(SUM(billing_amount) / 1000000.0, 2)                    AS total_revenue_millions,
    ROUND(AVG(billing_amount), 2)                                AS avg_billing_per_patient,
    ROUND(AVG(length_of_stay), 2)                                AS avg_los_days,
    ROUND(AVG(cost_per_day), 2)                                  AS avg_cost_per_day,
    COUNT(DISTINCT medical_condition)                            AS unique_conditions,
    COUNT(DISTINCT insurance_provider)                           AS unique_insurers,
    SUM(CASE WHEN test_results = 'Abnormal'  THEN 1 ELSE 0 END)  AS total_abnormal_cases,
    SUM(CASE WHEN test_results = 'Normal'    THEN 1 ELSE 0 END)  AS total_normal_cases,
    ROUND(SUM(CASE WHEN test_results = 'Abnormal' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS overall_abnormal_rate_pct,
    SUM(CASE WHEN admission_type = 'Emergency' THEN 1 ELSE 0 END) AS emergency_admissions,
    SUM(CASE WHEN admission_type = 'Urgent'    THEN 1 ELSE 0 END) AS urgent_admissions,
    SUM(CASE WHEN admission_type = 'Elective'  THEN 1 ELSE 0 END) AS elective_admissions,
    SUM(CASE WHEN billing_flag = 'refund_or_credit' THEN 1 ELSE 0 END) AS refund_records,
    ROUND(SUM(CASE WHEN billing_flag = 'refund_or_credit' THEN billing_amount ELSE 0 END), 2) AS total_refund_amount
FROM healthcare;

-- Preview
-- SELECT * FROM vw_executive_kpis;


-- ────────────────────────────────────────────────────────────
--  VIEW 6: Patient Demographics Summary
--  Use: Power BI Page 4 — demographics visuals
-- ────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW vw_patient_demographics AS
SELECT
    age_group,
    gender,
    blood_type,
    medical_condition,
    COUNT(*)                       AS patient_count,
    ROUND(AVG(age), 1)             AS avg_age,
    ROUND(AVG(billing_amount), 2)  AS avg_billing,
    ROUND(AVG(length_of_stay), 2)  AS avg_los
FROM healthcare
WHERE billing_flag = 'normal'
GROUP BY age_group, gender, blood_type, medical_condition
ORDER BY age_group, gender, medical_condition;

-- Preview
-- SELECT * FROM vw_patient_demographics;


-- ────────────────────────────────────────────────────────────
--  VERIFY ALL VIEWS CREATED
-- ────────────────────────────────────────────────────────────
SELECT 'vw_diagnosis_cost_summary'   AS view_name, 'Condition-level cost KPIs'          AS description UNION ALL
SELECT 'vw_high_billing_patients'    AS view_name, 'Top 10% billing patient list'        AS description UNION ALL
SELECT 'vw_insurer_performance'      AS view_name, 'Insurance provider revenue & volume' AS description UNION ALL
SELECT 'vw_monthly_admission_trends' AS view_name, 'Time series for line charts'         AS description UNION ALL
SELECT 'vw_executive_kpis'           AS view_name, 'Single-row KPI card data'            AS description UNION ALL
SELECT 'vw_patient_demographics'     AS view_name, 'Demographics breakdown'              AS description;
