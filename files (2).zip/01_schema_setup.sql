-- ============================================================
--  Healthcare Diagnosis & Financial Analysis
--  File: 01_schema_setup.sql
--  Author: Akash Mishra
--  Description: Create all tables and load data from CSV
-- ============================================================

-- ── Drop tables if re-running ────────────────────────────────
DROP TABLE IF EXISTS billing;
DROP TABLE IF EXISTS admissions;
DROP TABLE IF EXISTS patients;
DROP TABLE IF EXISTS doctors;
DROP TABLE IF EXISTS hospitals;
DROP TABLE IF EXISTS insurance_providers;
DROP TABLE IF EXISTS medical_conditions;
DROP TABLE IF EXISTS medications;

-- ============================================================
--  DIMENSION TABLES
-- ============================================================

-- Medical Conditions lookup
CREATE TABLE medical_conditions (
    condition_id   SERIAL PRIMARY KEY,
    condition_name VARCHAR(100) NOT NULL UNIQUE,
    category       VARCHAR(50)  -- chronic / acute / metabolic
);

INSERT INTO medical_conditions (condition_name, category) VALUES
    ('Arthritis',    'chronic'),
    ('Asthma',       'chronic'),
    ('Cancer',       'acute'),
    ('Diabetes',     'metabolic'),
    ('Hypertension', 'chronic'),
    ('Obesity',      'metabolic');

-- Insurance Providers lookup
CREATE TABLE insurance_providers (
    provider_id   SERIAL PRIMARY KEY,
    provider_name VARCHAR(100) NOT NULL UNIQUE,
    provider_type VARCHAR(50)  -- public / private
);

INSERT INTO insurance_providers (provider_name, provider_type) VALUES
    ('Aetna',            'private'),
    ('Blue Cross',       'private'),
    ('Cigna',            'private'),
    ('Medicare',         'public'),
    ('UnitedHealthcare', 'private');

-- Medications lookup
CREATE TABLE medications (
    medication_id   SERIAL PRIMARY KEY,
    medication_name VARCHAR(100) NOT NULL UNIQUE,
    drug_class      VARCHAR(100)
);

INSERT INTO medications (medication_name, drug_class) VALUES
    ('Aspirin',      'Analgesic / Anti-inflammatory'),
    ('Ibuprofen',    'NSAID'),
    ('Lipitor',      'Statin'),
    ('Paracetamol',  'Analgesic / Antipyretic'),
    ('Penicillin',   'Antibiotic');

-- ============================================================
--  CORE TABLES
-- ============================================================

-- Patients
CREATE TABLE patients (
    patient_id   SERIAL PRIMARY KEY,
    patient_name VARCHAR(150) NOT NULL,
    age          INT          NOT NULL CHECK (age BETWEEN 1 AND 120),
    gender       VARCHAR(10)  NOT NULL CHECK (gender IN ('Male', 'Female')),
    blood_type   VARCHAR(5)   NOT NULL,
    age_group    VARCHAR(30)
);

-- Hospitals
CREATE TABLE hospitals (
    hospital_id   SERIAL PRIMARY KEY,
    hospital_name VARCHAR(200) NOT NULL UNIQUE
);

-- Doctors
CREATE TABLE doctors (
    doctor_id   SERIAL PRIMARY KEY,
    doctor_name VARCHAR(150) NOT NULL,
    hospital_id INT REFERENCES hospitals(hospital_id)
);

-- Admissions (fact table)
CREATE TABLE admissions (
    admission_id      SERIAL PRIMARY KEY,
    patient_id        INT          NOT NULL REFERENCES patients(patient_id),
    condition_id      INT          NOT NULL REFERENCES medical_conditions(condition_id),
    doctor_id         INT          REFERENCES doctors(doctor_id),
    hospital_id       INT          REFERENCES hospitals(hospital_id),
    provider_id       INT          REFERENCES insurance_providers(provider_id),
    medication_id     INT          REFERENCES medications(medication_id),
    admission_date    DATE         NOT NULL,
    discharge_date    DATE         NOT NULL,
    admission_type    VARCHAR(20)  NOT NULL CHECK (admission_type IN ('Urgent', 'Emergency', 'Elective')),
    room_number       INT,
    test_results      VARCHAR(20)  CHECK (test_results IN ('Normal', 'Inconclusive', 'Abnormal')),
    length_of_stay    INT          GENERATED ALWAYS AS (discharge_date - admission_date) STORED,
    admission_year    INT          GENERATED ALWAYS AS (EXTRACT(YEAR  FROM admission_date)::INT) STORED,
    admission_month   INT          GENERATED ALWAYS AS (EXTRACT(MONTH FROM admission_date)::INT) STORED,
    admission_quarter INT          GENERATED ALWAYS AS (EXTRACT(QUARTER FROM admission_date)::INT) STORED
);

-- Billing (financial fact table)
CREATE TABLE billing (
    billing_id     SERIAL PRIMARY KEY,
    admission_id   INT            NOT NULL REFERENCES admissions(admission_id),
    patient_id     INT            NOT NULL REFERENCES patients(patient_id),
    provider_id    INT            REFERENCES insurance_providers(provider_id),
    billing_amount NUMERIC(12,2)  NOT NULL,
    billing_flag   VARCHAR(20)    DEFAULT 'normal' CHECK (billing_flag IN ('normal','refund_or_credit')),
    high_billing_flag VARCHAR(20) DEFAULT 'normal_cost',
    cost_per_day   NUMERIC(12,2)
);

-- ============================================================
--  INDEXES for query performance
-- ============================================================
CREATE INDEX idx_admissions_condition  ON admissions(condition_id);
CREATE INDEX idx_admissions_date       ON admissions(admission_date);
CREATE INDEX idx_admissions_year       ON admissions(admission_year);
CREATE INDEX idx_admissions_type       ON admissions(admission_type);
CREATE INDEX idx_admissions_patient    ON admissions(patient_id);
CREATE INDEX idx_billing_amount        ON billing(billing_amount);
CREATE INDEX idx_billing_provider      ON billing(provider_id);
CREATE INDEX idx_billing_flag          ON billing(billing_flag);
CREATE INDEX idx_patients_age_group    ON patients(age_group);

-- ============================================================
--  LOAD DATA FROM CSV  (PostgreSQL COPY command)
--  Adjust file path to your local environment
-- ============================================================

/*
-- Run this block after creating the tables above.
-- It loads data from the cleaned CSV into a staging table,
-- then distributes rows into normalised tables.

-- Step 1: Create staging table
CREATE TEMP TABLE staging AS
SELECT * FROM admissions LIMIT 0;  -- empty shell

-- Step 2: Load CSV into staging
COPY staging FROM '/path/to/healthcare_cleaned.csv'
    DELIMITER ',' CSV HEADER;

-- Step 3: Insert into dimension & fact tables
-- (Use INSERT ... SELECT from staging to populate each table)
*/

-- ============================================================
--  QUICK SANITY CHECK  (run after loading data)
-- ============================================================
-- SELECT 'patients'    AS tbl, COUNT(*) FROM patients    UNION ALL
-- SELECT 'admissions'  AS tbl, COUNT(*) FROM admissions  UNION ALL
-- SELECT 'billing'     AS tbl, COUNT(*) FROM billing      UNION ALL
-- SELECT 'hospitals'   AS tbl, COUNT(*) FROM hospitals;

SELECT 'Schema created successfully' AS status;
