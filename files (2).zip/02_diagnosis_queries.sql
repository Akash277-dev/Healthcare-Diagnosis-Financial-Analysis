-- ============================================================
--  Healthcare Diagnosis & Financial Analysis
--  File: 02_diagnosis_queries.sql
--  Author: Akash Mishra
--  Description: Diagnosis-focused analytical queries
-- ============================================================
--
--  NOTE: These queries are written for the FLAT cleaned CSV
--  loaded as a single table called `healthcare`.
--  To use with the normalised schema, join via condition_id etc.
--
--  Load flat table:
--    CREATE TABLE healthcare AS
--    SELECT * FROM read_csv_auto('healthcare_cleaned.csv');  -- DuckDB
--    -- OR use PostgreSQL COPY command
-- ============================================================


-- ────────────────────────────────────────────────────────────
--  Q1: Patient count by medical condition (ranked)
-- ────────────────────────────────────────────────────────────
SELECT
    medical_condition,
    COUNT(*)                                          AS patient_count,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 2) AS pct_of_total,
    RANK() OVER (ORDER BY COUNT(*) DESC)              AS rank
FROM healthcare
GROUP BY medical_condition
ORDER BY patient_count DESC;


-- ────────────────────────────────────────────────────────────
--  Q2: Condition by age group — cross tab
-- ────────────────────────────────────────────────────────────
SELECT
    age_group,
    COUNT(*)                                               AS total_patients,
    SUM(CASE WHEN medical_condition = 'Cancer'      THEN 1 ELSE 0 END) AS cancer,
    SUM(CASE WHEN medical_condition = 'Diabetes'    THEN 1 ELSE 0 END) AS diabetes,
    SUM(CASE WHEN medical_condition = 'Hypertension'THEN 1 ELSE 0 END) AS hypertension,
    SUM(CASE WHEN medical_condition = 'Obesity'     THEN 1 ELSE 0 END) AS obesity,
    SUM(CASE WHEN medical_condition = 'Arthritis'   THEN 1 ELSE 0 END) AS arthritis,
    SUM(CASE WHEN medical_condition = 'Asthma'      THEN 1 ELSE 0 END) AS asthma
FROM healthcare
GROUP BY age_group
ORDER BY age_group;


-- ────────────────────────────────────────────────────────────
--  Q3: Year-over-year admission trend by condition
-- ────────────────────────────────────────────────────────────
SELECT
    admission_year,
    medical_condition,
    COUNT(*)                                                          AS admissions,
    LAG(COUNT(*)) OVER (PARTITION BY medical_condition ORDER BY admission_year) AS prev_year,
    COUNT(*) - LAG(COUNT(*)) OVER (PARTITION BY medical_condition ORDER BY admission_year) AS yoy_change,
    ROUND(
        (COUNT(*) - LAG(COUNT(*)) OVER (PARTITION BY medical_condition ORDER BY admission_year))
        * 100.0
        / NULLIF(LAG(COUNT(*)) OVER (PARTITION BY medical_condition ORDER BY admission_year), 0),
    2) AS yoy_pct_change
FROM healthcare
GROUP BY admission_year, medical_condition
ORDER BY medical_condition, admission_year;


-- ────────────────────────────────────────────────────────────
--  Q4: Monthly seasonality — admissions per month
-- ────────────────────────────────────────────────────────────
SELECT
    admission_month,
    admission_month_name,
    COUNT(*)                         AS total_admissions,
    ROUND(AVG(billing_amount), 2)    AS avg_billing,
    ROUND(AVG(length_of_stay), 2)    AS avg_los
FROM healthcare
GROUP BY admission_month, admission_month_name
ORDER BY admission_month;


-- ────────────────────────────────────────────────────────────
--  Q5: Test result breakdown by condition
-- ────────────────────────────────────────────────────────────
SELECT
    medical_condition,
    COUNT(*)                                                              AS total,
    SUM(CASE WHEN test_results = 'Normal'       THEN 1 ELSE 0 END)       AS normal_count,
    SUM(CASE WHEN test_results = 'Inconclusive' THEN 1 ELSE 0 END)       AS inconclusive_count,
    SUM(CASE WHEN test_results = 'Abnormal'     THEN 1 ELSE 0 END)       AS abnormal_count,
    ROUND(SUM(CASE WHEN test_results = 'Normal'       THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS normal_pct,
    ROUND(SUM(CASE WHEN test_results = 'Abnormal'     THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS abnormal_pct
FROM healthcare
GROUP BY medical_condition
ORDER BY abnormal_pct DESC;


-- ────────────────────────────────────────────────────────────
--  Q6: Average length of stay by condition and admission type
-- ────────────────────────────────────────────────────────────
SELECT
    medical_condition,
    admission_type,
    COUNT(*)                           AS patient_count,
    ROUND(AVG(length_of_stay), 2)      AS avg_los_days,
    MIN(length_of_stay)                AS min_los,
    MAX(length_of_stay)                AS max_los,
    ROUND(STDDEV(length_of_stay), 2)   AS stddev_los
FROM healthcare
GROUP BY medical_condition, admission_type
ORDER BY medical_condition, avg_los_days DESC;


-- ────────────────────────────────────────────────────────────
--  Q7: Medication frequency by condition
-- ────────────────────────────────────────────────────────────
SELECT
    medical_condition,
    medication,
    COUNT(*)                                          AS prescription_count,
    ROUND(COUNT(*) * 100.0 /
        SUM(COUNT(*)) OVER (PARTITION BY medical_condition), 2) AS pct_within_condition
FROM healthcare
GROUP BY medical_condition, medication
ORDER BY medical_condition, prescription_count DESC;


-- ────────────────────────────────────────────────────────────
--  Q8: Most common condition per age group
-- ────────────────────────────────────────────────────────────
WITH ranked AS (
    SELECT
        age_group,
        medical_condition,
        COUNT(*) AS cnt,
        RANK() OVER (PARTITION BY age_group ORDER BY COUNT(*) DESC) AS rnk
    FROM healthcare
    GROUP BY age_group, medical_condition
)
SELECT
    age_group,
    medical_condition AS most_common_condition,
    cnt               AS patient_count
FROM ranked
WHERE rnk = 1
ORDER BY age_group;


-- ────────────────────────────────────────────────────────────
--  Q9: Admission type distribution per condition (%)
-- ────────────────────────────────────────────────────────────
SELECT
    medical_condition,
    COUNT(*)                                                                    AS total,
    ROUND(SUM(CASE WHEN admission_type = 'Emergency' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS emergency_pct,
    ROUND(SUM(CASE WHEN admission_type = 'Urgent'    THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS urgent_pct,
    ROUND(SUM(CASE WHEN admission_type = 'Elective'  THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS elective_pct
FROM healthcare
GROUP BY medical_condition
ORDER BY emergency_pct DESC;


-- ────────────────────────────────────────────────────────────
--  Q10: Gender split by condition
-- ────────────────────────────────────────────────────────────
SELECT
    medical_condition,
    SUM(CASE WHEN gender = 'Male'   THEN 1 ELSE 0 END) AS male_count,
    SUM(CASE WHEN gender = 'Female' THEN 1 ELSE 0 END) AS female_count,
    ROUND(SUM(CASE WHEN gender = 'Male'   THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS male_pct,
    ROUND(SUM(CASE WHEN gender = 'Female' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS female_pct
FROM healthcare
GROUP BY medical_condition
ORDER BY medical_condition;
