-- ============================================================
--  Healthcare Diagnosis & Financial Analysis
--  File: 03_financial_queries.sql
--  Author: Akash Mishra
--  Description: Financial & billing analytical queries
-- ============================================================


-- ────────────────────────────────────────────────────────────
--  Q1: Average, median, min, max billing by condition
-- ────────────────────────────────────────────────────────────
SELECT
    medical_condition,
    COUNT(*)                                        AS patient_count,
    ROUND(AVG(billing_amount), 2)                   AS avg_billing,
    ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP
          (ORDER BY billing_amount), 2)             AS median_billing,
    ROUND(MIN(billing_amount), 2)                   AS min_billing,
    ROUND(MAX(billing_amount), 2)                   AS max_billing,
    ROUND(STDDEV(billing_amount), 2)                AS stddev_billing,
    ROUND(SUM(billing_amount) / 1000000.0, 3)       AS total_revenue_millions
FROM healthcare
WHERE billing_flag = 'normal'
GROUP BY medical_condition
ORDER BY avg_billing DESC;


-- ────────────────────────────────────────────────────────────
--  Q2: Insurance provider — volume, revenue, avg claim
-- ────────────────────────────────────────────────────────────
SELECT
    insurance_provider,
    COUNT(*)                                               AS patient_count,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 2)     AS volume_pct,
    ROUND(SUM(billing_amount) / 1000000.0, 3)              AS total_revenue_millions,
    ROUND(AVG(billing_amount), 2)                          AS avg_claim,
    ROUND(MIN(billing_amount), 2)                          AS min_claim,
    ROUND(MAX(billing_amount), 2)                          AS max_claim,
    RANK() OVER (ORDER BY SUM(billing_amount) DESC)        AS revenue_rank
FROM healthcare
WHERE billing_flag = 'normal'
GROUP BY insurance_provider
ORDER BY total_revenue_millions DESC;


-- ────────────────────────────────────────────────────────────
--  Q3: Billing vs length of stay — correlation proxy
-- ────────────────────────────────────────────────────────────
SELECT
    length_of_stay,
    COUNT(*)                       AS patient_count,
    ROUND(AVG(billing_amount), 2)  AS avg_billing,
    ROUND(MIN(billing_amount), 2)  AS min_billing,
    ROUND(MAX(billing_amount), 2)  AS max_billing
FROM healthcare
WHERE billing_flag = 'normal'
  AND length_of_stay > 0
GROUP BY length_of_stay
ORDER BY length_of_stay;


-- ────────────────────────────────────────────────────────────
--  Q4: Admission type — financial impact
-- ────────────────────────────────────────────────────────────
SELECT
    admission_type,
    COUNT(*)                                            AS patient_count,
    ROUND(AVG(billing_amount), 2)                       AS avg_billing,
    ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP
          (ORDER BY billing_amount), 2)                 AS median_billing,
    ROUND(SUM(billing_amount) / 1000000.0, 3)           AS total_revenue_millions,
    ROUND(AVG(length_of_stay), 2)                       AS avg_los,
    ROUND(AVG(cost_per_day), 2)                         AS avg_cost_per_day
FROM healthcare
WHERE billing_flag = 'normal'
GROUP BY admission_type
ORDER BY avg_billing DESC;


-- ────────────────────────────────────────────────────────────
--  Q5: High-cost patient analysis (top 10% billing)
-- ────────────────────────────────────────────────────────────
WITH thresholds AS (
    SELECT PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY billing_amount) AS p90
    FROM healthcare
    WHERE billing_flag = 'normal'
)
SELECT
    h.medical_condition,
    COUNT(*)                                           AS high_cost_patients,
    ROUND(AVG(h.billing_amount), 2)                    AS avg_billing,
    ROUND(SUM(h.billing_amount) / 1000000.0, 3)        AS total_revenue_millions,
    ROUND(AVG(h.length_of_stay), 2)                    AS avg_los
FROM healthcare h, thresholds t
WHERE h.billing_amount >= t.p90
  AND h.billing_flag = 'normal'
GROUP BY h.medical_condition
ORDER BY total_revenue_millions DESC;


-- ────────────────────────────────────────────────────────────
--  Q6: Cost per day by condition and admission type
-- ────────────────────────────────────────────────────────────
SELECT
    medical_condition,
    admission_type,
    COUNT(*)                          AS patient_count,
    ROUND(AVG(cost_per_day), 2)       AS avg_cost_per_day,
    ROUND(MIN(cost_per_day), 2)       AS min_cost_per_day,
    ROUND(MAX(cost_per_day), 2)       AS max_cost_per_day
FROM healthcare
WHERE billing_flag = 'normal'
  AND cost_per_day > 0
GROUP BY medical_condition, admission_type
ORDER BY avg_cost_per_day DESC;


-- ────────────────────────────────────────────────────────────
--  Q7: Year-over-year revenue trend
-- ────────────────────────────────────────────────────────────
SELECT
    admission_year,
    COUNT(*)                                                        AS admissions,
    ROUND(SUM(billing_amount) / 1000000.0, 3)                       AS total_revenue_millions,
    ROUND(AVG(billing_amount), 2)                                   AS avg_billing,
    LAG(ROUND(SUM(billing_amount)/1000000.0,3))
        OVER (ORDER BY admission_year)                              AS prev_year_revenue_millions,
    ROUND(
        (SUM(billing_amount) - LAG(SUM(billing_amount)) OVER (ORDER BY admission_year))
        * 100.0
        / NULLIF(LAG(SUM(billing_amount)) OVER (ORDER BY admission_year), 0),
    2) AS yoy_revenue_growth_pct
FROM healthcare
WHERE billing_flag = 'normal'
GROUP BY admission_year
ORDER BY admission_year;


-- ────────────────────────────────────────────────────────────
--  Q8: Negative billing investigation (refunds / credits)
-- ────────────────────────────────────────────────────────────
SELECT
    medical_condition,
    insurance_provider,
    admission_type,
    COUNT(*)                           AS refund_records,
    ROUND(SUM(billing_amount), 2)      AS total_refund_amount,
    ROUND(AVG(billing_amount), 2)      AS avg_refund_amount
FROM healthcare
WHERE billing_flag = 'refund_or_credit'
GROUP BY medical_condition, insurance_provider, admission_type
ORDER BY total_refund_amount ASC;


-- ────────────────────────────────────────────────────────────
--  Q9: Revenue by condition AND insurance provider (matrix)
-- ────────────────────────────────────────────────────────────
SELECT
    medical_condition,
    ROUND(SUM(CASE WHEN insurance_provider = 'Aetna'            THEN billing_amount ELSE 0 END) / 1000.0, 1) AS aetna_k,
    ROUND(SUM(CASE WHEN insurance_provider = 'Blue Cross'       THEN billing_amount ELSE 0 END) / 1000.0, 1) AS blue_cross_k,
    ROUND(SUM(CASE WHEN insurance_provider = 'Cigna'            THEN billing_amount ELSE 0 END) / 1000.0, 1) AS cigna_k,
    ROUND(SUM(CASE WHEN insurance_provider = 'Medicare'         THEN billing_amount ELSE 0 END) / 1000.0, 1) AS medicare_k,
    ROUND(SUM(CASE WHEN insurance_provider = 'UnitedHealthcare' THEN billing_amount ELSE 0 END) / 1000.0, 1) AS uhc_k,
    ROUND(SUM(billing_amount) / 1000.0, 1)                                                                   AS total_k
FROM healthcare
WHERE billing_flag = 'normal'
GROUP BY medical_condition
ORDER BY total_k DESC;


-- ────────────────────────────────────────────────────────────
--  Q10: Test result impact on billing
-- ────────────────────────────────────────────────────────────
SELECT
    test_results,
    medical_condition,
    COUNT(*)                          AS patient_count,
    ROUND(AVG(billing_amount), 2)     AS avg_billing,
    ROUND(AVG(length_of_stay), 2)     AS avg_los
FROM healthcare
WHERE billing_flag = 'normal'
GROUP BY test_results, medical_condition
ORDER BY test_results, avg_billing DESC;


-- ────────────────────────────────────────────────────────────
--  Q11: Top 20 highest individual billing records
-- ────────────────────────────────────────────────────────────
SELECT
    patient_name,
    age,
    gender,
    medical_condition,
    insurance_provider,
    admission_type,
    admission_date,
    length_of_stay,
    ROUND(billing_amount, 2)    AS billing_amount,
    ROUND(cost_per_day, 2)      AS cost_per_day,
    test_results
FROM healthcare
WHERE billing_flag = 'normal'
ORDER BY billing_amount DESC
LIMIT 20;


-- ────────────────────────────────────────────────────────────
--  Q12: Quarterly revenue trend per condition
-- ────────────────────────────────────────────────────────────
SELECT
    admission_year,
    admission_quarter,
    medical_condition,
    COUNT(*)                                    AS admissions,
    ROUND(SUM(billing_amount) / 1000.0, 1)      AS revenue_thousands,
    ROUND(AVG(billing_amount), 2)               AS avg_billing
FROM healthcare
WHERE billing_flag = 'normal'
GROUP BY admission_year, admission_quarter, medical_condition
ORDER BY admission_year, admission_quarter, medical_condition;
